package com.hims.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author bruce
 * @since 2021-09-04
 */
@Controller
@RequestMapping("/role")
public class RoleController {

}
