package com.hims.service;

import com.hims.pojo.RolePermission;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author bruce
 * @since 2021-09-04
 */
public interface IRolePermissionService extends IService<RolePermission> {

}
