package com.hims.service;

import com.hims.pojo.Wardupdate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 床位费用计算表 服务类
 * </p>
 *
 * @author bruce
 * @since 2021-08-31
 */
public interface IWardupdateService extends IService<Wardupdate> {

}
