package com.hims.service;

import com.hims.pojo.Log;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author bruce
 * @since 2021-09-01
 */
public interface ILogService extends IService<Log> {

}
