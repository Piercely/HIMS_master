package com.hims.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hims.pojo.Ward;

public interface WardService extends IService<Ward> {
}
