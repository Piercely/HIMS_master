package com.hims.service;

import com.hims.pojo.Fee;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author bruce
 * @since 2021-08-31
 */
public interface IFeeService extends IService<Fee> {

}
