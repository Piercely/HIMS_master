package com.hims.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hims.pojo.Paracode;

public interface ParacodeService extends IService<Paracode> {
}
