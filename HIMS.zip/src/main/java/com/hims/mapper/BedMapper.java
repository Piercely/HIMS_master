package com.hims.mapper;

import com.hims.pojo.Bed;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bruce
 * @since 2021-08-27
 */
public interface BedMapper extends BaseMapper<Bed> {

}
