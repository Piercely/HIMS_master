package com.hims.mapper;

import com.hims.pojo.Wardupdate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 床位费用计算表 Mapper 接口
 * </p>
 *
 * @author bruce
 * @since 2021-08-31
 */
public interface WardupdateMapper extends BaseMapper<Wardupdate> {

}
