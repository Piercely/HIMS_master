package com.hims.mapper;

import com.hims.pojo.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bruce
 * @since 2021-08-25
 */
public interface UserMapper extends BaseMapper<User> {

}
