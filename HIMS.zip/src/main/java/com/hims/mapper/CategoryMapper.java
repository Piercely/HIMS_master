package com.hims.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hims.pojo.Category;

public interface CategoryMapper extends BaseMapper<Category> {
}
