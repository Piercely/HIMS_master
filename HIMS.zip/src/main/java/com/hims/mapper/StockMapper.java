package com.hims.mapper;

import com.hims.pojo.Stock;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bruce
 * @since 2021-08-26
 */
public interface StockMapper extends BaseMapper<Stock> {

}
