package com.hims.mapper;

import com.hims.pojo.Withdrawal;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bruce
 * @since 2021-08-30
 */
public interface WithdrawalMapper extends BaseMapper<Withdrawal> {

}
