package com.hims.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hims.pojo.Ward;

import java.util.stream.BaseStream;

public interface WardMapper extends BaseMapper<Ward> {
}
