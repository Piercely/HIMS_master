package com.hims.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hims.pojo.Paracode;

public interface ParacodeMapper extends BaseMapper<Paracode> {
}
