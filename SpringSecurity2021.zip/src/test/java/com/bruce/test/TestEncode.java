package com.bruce.test;

import org.junit.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.*;
import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;

import java.util.HashMap;
import java.util.Map;

/**
 * 测试加密算法
 */
public class TestEncode {

    @Test
    public void test1(){
        PasswordEncoder messageDigestPasswordEncoder = new MessageDigestPasswordEncoder("md5");
        String admin1 = messageDigestPasswordEncoder.encode("admin");
        String admin2 = messageDigestPasswordEncoder.encode("admin");
        System.out.println(admin1);
        System.out.println(admin2);

        PasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
        String bruce1 = bCryptPasswordEncoder.encode("12345");
        String bruce2 = bCryptPasswordEncoder.encode("12345");
        String bruce3 = bCryptPasswordEncoder.encode("12345");
        System.out.println(bruce1);
        System.out.println(bruce2);
        System.out.println(bruce3);
    }

    @Test
    public void test2(){
        Map<String, PasswordEncoder> encoders = new HashMap();
        encoders.put("bcrypt", new BCryptPasswordEncoder());
        encoders.put("ldap", new LdapShaPasswordEncoder());
        encoders.put("MD4", new Md4PasswordEncoder());
        encoders.put("MD5", new MessageDigestPasswordEncoder("MD5"));
        encoders.put("noop", NoOpPasswordEncoder.getInstance());
        encoders.put("pbkdf2", new Pbkdf2PasswordEncoder());
        encoders.put("scrypt", new SCryptPasswordEncoder());
        encoders.put("SHA-1", new MessageDigestPasswordEncoder("SHA-1"));
        encoders.put("SHA-256", new MessageDigestPasswordEncoder("SHA-256"));
        encoders.put("sha256", new StandardPasswordEncoder());
    }
}
