package com.bruce.service.impl;

import com.bruce.mapper.UserMapper;
import com.bruce.pojo.UserPojo;
import com.bruce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl  implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserPojo userPojo = userMapper.queryUserPojoByUserName(username);
        if(userPojo!=null){
            //账号存在，密码对嘛？
            //TODO:当前用户的权限的集合，需要从数据库中加载权限
            List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
            return new User(userPojo.getUsername(),userPojo.getPassword(),userPojo.getState()==0,true,true,true, authorities);
        }
        //账号不存在，数据库中查询不到账号
        return null;
    }
}
