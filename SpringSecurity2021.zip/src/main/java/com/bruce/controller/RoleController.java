package com.bruce.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("role")
public class RoleController {

    @Secured(value = {"ROLE_USER"})
    @RequestMapping("/find")
    public String query(){
        System.out.println("角色查询..");
        return "/success.jsp";
    }

    @Secured(value = {"ROLE_XXX","ROLE_111"})
    @RequestMapping("/update")
    public String update(){
        System.out.println("角色更新...");
        return "/success.jsp";
    }
}
