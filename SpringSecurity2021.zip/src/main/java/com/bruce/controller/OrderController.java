package com.bruce.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("order")
public class OrderController {

    @PreAuthorize(value = "hasAnyRole('ROLE_USER')")
    @RequestMapping("/find")
    public String query(){
        System.out.println("订单查询..");
        return "/success.jsp";
    }

    @PreAuthorize(value = "hasAnyRole('ROLE_CC')")
    @RequestMapping("/update")
    public String update(){
        System.out.println("订单更新...");
        return "/success.jsp";
    }
}
