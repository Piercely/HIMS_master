package com.bruce.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.security.RolesAllowed;


@Controller
@RequestMapping("/user")
public class UserController {

    @RolesAllowed(value = {"ROLE_ADMIN"})
    @RequestMapping("/find")
    public String query(){
        System.out.println("用户查询..");
        return "/success.jsp";
    }

    @RolesAllowed(value = {"ROLE_USER"})
    @RequestMapping("/update")
    public String update(){
        System.out.println("用户更新...");
        return "/success.jsp";
    }

}
