package com.bruce.mapper;

import com.bruce.pojo.UserPojo;

public interface UserMapper {

    UserPojo queryUserPojoByUserName(String username);
}
