package com.bruce.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserPojo {

    private Integer id;
    private String username;
    private String password;
    private String salt;
    private String nickname;
    private Integer state;  // 1冻结  0启用
}
