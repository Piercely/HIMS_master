create definer = root@localhost trigger delete_trigger_on_paracode
    after delete
    on paracode
    for each row
BEGIN
IF (old.code = '004') THEN
delete from bed where ward=old.parameter_values;
END IF;
END;

