create definer = root@localhost event event_AutoDeleteLogs on schedule
    every '1' DAY
        starts '2019-04-25 00:00:00'
    on completion preserve
    enable
    do
    CALL AutoDeleteLogs();

