create
    definer = root@localhost function nextval(doctor_id varchar(6)) returns int
BEGIN  
UPDATE doctor SET current_value = current_value + increment WHERE Name = doctor_id;  
RETURN currval(seq_name);  
END;

