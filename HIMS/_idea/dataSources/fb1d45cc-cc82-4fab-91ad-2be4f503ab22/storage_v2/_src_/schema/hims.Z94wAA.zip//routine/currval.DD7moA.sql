create
    definer = root@localhost function currval(doctor_id varchar(6)) returns int
BEGIN  
DECLARE VALUE INTEGER;  
SET VALUE = 10001;  
SELECT current_value INTO VALUE FROM doctor WHERE NAME = doctor_id;  
RETURN VALUE;  
END;

