create definer = root@localhost trigger insert_trigger_on_paracode
    after insert
    on paracode
    for each row
BEGIN
IF (new.code = '003') THEN
insert into category(type,name) values(new.parameter_values,new.parameter_name);
END IF;
END;

